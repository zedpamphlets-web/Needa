# NeedA Ads — Expo setup

Do not install the old Cordova `cordova-admob-plus` plugin.

When the NeedA AdMob account is ready:

1. Create/select the Android app in Google AdMob.
2. Copy the Android App ID (`ca-app-pub-...~...`).
3. Install:
   `npx expo install react-native-google-mobile-ads`
4. Add its Expo config plugin to `app.json` with the real Android App ID.
5. Add test ad units while developing.
6. Build a new EAS development/preview build. The ads package contains native code and will not work in Expo Go.
7. Before Play Store release, mark the app as containing ads in Play Console and complete the required consent/privacy setup.

Never ship a fake App ID. A missing/invalid App ID can make the native build fail or the app fail at startup.
