# NeedA Expo build health checklist

This archive is an Expo SDK 57 / React Native 0.86 project using Continuous Native Generation (CNG).

## Fixed in this release
- Removed the literal `\\n` token that broke `app/_layout.tsx`.
- Removed the obsolete `newArchEnabled` app-config field; SDK 57 already uses the New Architecture.
- Aligned React Native and React with Expo SDK 57.
- Aligned Expo Router, Image Picker, Location, Splash Screen, Status Bar, Constants, Font, and Linking packages with SDK 57.
- Added the Expo packages that the previous archive was missing (`expo-font`, `expo-linking`).
- Removed uses of `StyleSheet.absoluteFillObject` from the app code and replaced them with explicit absolute positioning for React Native 0.86 compatibility.
- Made Firebase configuration environment-based and safe when it is not configured yet, so a missing Firebase config does not crash the bundle.
- Added `.env.example` for Firebase values.
- Kept EAS preview as an APK and production as an AAB.

## Before production
1. Copy `.env.example` to `.env`.
2. Add the Firebase Web App configuration values.
3. Run `npx expo install --fix`.
4. Run `npx expo-doctor` and make sure it reports no dependency/config errors.
5. Build the preview APK with `eas build --platform android --profile preview`.
6. Test the APK on a physical Android phone.
7. Build the Play Store AAB with `eas build --platform android --profile production`.
