# NeedA — Expo / React Native v1

This is the real Expo/React Native conversion of the previous Cordova/HTML NeedA project.

## Expo architecture
- Expo SDK 57
- React Native New Architecture (SDK 55+ requires it)
- Expo Router for native file-based navigation
- Continuous Native Generation (no committed `android/` or `ios/` folders)
- EAS Build profiles for APK preview and Play Store AAB production
- Expo Splash Screen config plugin
- Native camera/gallery and location permissions
- Firebase Auth + Firestore + Storage
- AsyncStorage cache and offline post queue
- Expiry filtering for updates/posts
- Local NeedA branding/assets

## Build from a terminal
1. `npm install`
2. `npx expo-doctor`
3. `npx expo start`
4. `npx eas login`
5. `npx eas build:configure` (links this project to your Expo account and can add the EAS project ID)
6. APK: `npx eas build --platform android --profile preview`
7. Play Store AAB: `npx eas build --platform android --profile production`

A preview profile is configured as an APK. Production is configured as an AAB.

## Important
- Do not add Cordova plugins or `cordova.js` to this project.
- Do not manually edit generated Gradle files unless a native change truly requires it. Expo CNG generates them from app config.
- After changing native plugins, permissions, package name, or other native configuration, create a new native build.
- JavaScript/UI-only changes can be delivered with EAS Update after the project is linked and an update channel/runtime is configured.
- The app's offline cache can show previously loaded data. Fresh server data still requires connectivity.
- Posts created while offline are queued locally and attempted again when the app becomes online.

## Ads
The old `cordova-admob-plus` plugin is deliberately not used.
For Expo, the supported route is a native Expo config plugin such as `react-native-google-mobile-ads`, but it requires a real AdMob App ID before the native build. See `ADS_SETUP.md`. Do not put a fake App ID in `app.json`.

## Firebase
The Firebase web client configuration from the existing NeedA project is retained in `src/lib/firebase.ts`. Firebase client config is intended to be present in client applications; secure access is controlled by Firebase Authentication and Firestore/Storage security rules.

## Branding
NeedA colors are retained:
- Primary: `#4F3CC9`
- Dark: `#2E2178`
- Background: `#F6F6FB`

The native splash uses the NeedA logo. After the native splash is ready, the app shows the NeedA branded opening collage for the requested opening sequence.


## Firebase
This build is preconfigured with the Firebase Web App configuration from the previous NeedA v27 project. The values are client-side Firebase configuration, not a service-account credential.
