import React,{useEffect,useState} from 'react';
import {View,Text,StyleSheet,FlatList,Image,TouchableOpacity,TextInput} from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import {useRouter} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {fetchShops} from '../../src/lib/firebase';
import {cacheJson,readJson} from '../../src/lib/offline';
const purple='#4F3CC9';
export default function Shops(){
 const router=useRouter();const [items,setItems]=useState<any[]>([]);const [q,setQ]=useState('');
 useEffect(()=>{(async()=>{try{if(!(await NetInfo.fetch()).isConnected){setItems(await readJson('needa.shops',[]));return}const x=await fetchShops();setItems(x);await cacheJson('needa.shops',x)}catch{setItems(await readJson('needa.shops',[]))}})()},[]);
 const filtered=items.filter(x=>`${x.shopName||''} ${x.businessName||''} ${x.locationName||''}`.toLowerCase().includes(q.toLowerCase()));
 return <View style={s.page}><Text style={s.title}>Local Shops</Text><TextInput value={q} onChangeText={setQ} placeholder="Search shops..." style={s.search}/><FlatList data={filtered} numColumns={2} columnWrapperStyle={{gap:12}} contentContainerStyle={{paddingBottom:100,gap:12}} keyExtractor={x=>x.id} renderItem={({item})=><TouchableOpacity style={s.card} onPress={()=>router.push({pathname:'/shop/[id]',params:{id:item.id}})}><View style={s.img}>{item.logoUrl||item.photoUrl?<Image source={{uri:item.logoUrl||item.photoUrl}} style={s.im}/>:<Ionicons name="storefront-outline" size={38} color={purple}/>}</View><Text style={s.name} numberOfLines={1}>{item.shopName||item.businessName||'Local Shop'}</Text><Text style={s.loc} numberOfLines={1}>{item.locationName||'Zambia'}</Text></TouchableOpacity>}/></View>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#F6F6FB',padding:16},title:{fontSize:27,fontWeight:'900',color:'#1D1B2E',marginTop:12,marginBottom:14},search:{height:50,backgroundColor:'#fff',borderRadius:16,borderWidth:1,borderColor:'#E9E8F2',paddingHorizontal:15,marginBottom:15},card:{flex:1,maxWidth:'50%',backgroundColor:'#fff',borderRadius:18,padding:10,borderWidth:1,borderColor:'#E9E8F2'},img:{height:145,borderRadius:14,backgroundColor:'#EEEBFB',alignItems:'center',justifyContent:'center',overflow:'hidden'},im:{width:'100%',height:'100%',resizeMode:'cover'},name:{fontWeight:'800',fontSize:14,marginTop:8,color:'#1D1B2E'},loc:{fontSize:11,color:'#6B6878',marginTop:3}});
