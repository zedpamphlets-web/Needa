import React,{useEffect,useState} from 'react';
import {View,Text,StyleSheet,FlatList,TouchableOpacity,Image} from 'react-native';
import {fetchPosts} from '../../src/lib/firebase';
import {filterActive,readJson,cacheJson} from '../../src/lib/offline';
import NetInfo from '@react-native-community/netinfo';
import {useRouter} from 'expo-router';
const purple='#4F3CC9';
export default function Trading(){
 const router=useRouter();const [items,setItems]=useState<any[]>([]);
 useEffect(()=>{(async()=>{try{if(!(await NetInfo.fetch()).isConnected){setItems(await readJson('needa.posts',[]));return}const p=filterActive(await fetchPosts());setItems(p.filter((x:any)=>String(x.type||'').toLowerCase().includes('trad')||String(x.category||'').toLowerCase().includes('trad')));await cacheJson('needa.trading',p)}catch{setItems(await readJson('needa.trading',[]))}})()},[]);
 return <View style={s.page}><Text style={s.title}>Trading</Text><Text style={s.sub}>Buy, sell and exchange locally.</Text><FlatList data={items} numColumns={2} columnWrapperStyle={{gap:12}} contentContainerStyle={{gap:12,paddingBottom:100}} keyExtractor={x=>x.id} renderItem={({item})=><TouchableOpacity style={s.card} onPress={()=>router.push({pathname:'/post/[id]',params:{id:item.id}})}>{item.imageUrl?<Image source={{uri:item.imageUrl}} style={s.img}/>:<View style={s.img}/>}<Text style={s.name} numberOfLines={2}>{item.title||item.description||'Trading post'}</Text><Text style={s.price}>{item.price?`ZMW ${item.price}`:'Contact seller'}</Text></TouchableOpacity>}/></View>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#F6F6FB',padding:16},title:{fontSize:28,fontWeight:'900',color:'#1D1B2E',marginTop:12},sub:{color:'#6B6878',marginTop:5,marginBottom:16},card:{flex:1,maxWidth:'50%',backgroundColor:'#fff',borderRadius:18,padding:9,borderWidth:1,borderColor:'#E9E8F2'},img:{height:155,width:'100%',borderRadius:13,backgroundColor:'#EEEBFB'},name:{fontSize:13,fontWeight:'800',color:'#1D1B2E',marginTop:8},price:{fontSize:12,fontWeight:'900',color:'#D6304A',marginTop:5}});
