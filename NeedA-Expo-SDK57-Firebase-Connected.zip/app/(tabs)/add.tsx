import React,{useEffect,useState} from 'react';
import {View,Text,StyleSheet,TextInput,TouchableOpacity,Image,Alert,ScrollView} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import NetInfo from '@react-native-community/netinfo';
import {addDoc,collection} from 'firebase/firestore';
import {getStorage,ref,uploadBytes,getDownloadURL} from 'firebase/storage';
import {db,auth} from '../../src/lib/firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useRouter} from 'expo-router';
const purple='#4F3CC9';
export default function Add(){
 const router=useRouter();const [title,setTitle]=useState('');const [price,setPrice]=useState('');const [type,setType]=useState('Goods');const [image,setImage]=useState<string|null>(null);const [busy,setBusy]=useState(false);
 useEffect(()=>{(async()=>{await ImagePicker.requestMediaLibraryPermissionsAsync();await ImagePicker.requestCameraPermissionsAsync()})()},[]);
 const choose=async()=>{const r=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],quality:.82});if(!r.canceled)setImage(r.assets[0].uri)};
 const camera=async()=>{const r=await ImagePicker.launchCameraAsync({quality:.82});if(!r.canceled)setImage(r.assets[0].uri)};
 const submit=async()=>{
  if(!title.trim()){Alert.alert('NeedA','Add a title first.');return}
  setBusy(true);
  const data:any={title:title.trim(),price:price.trim(),type,createdAt:Date.now(),expiresAt:Date.now()+7*86400000,ownerId:auth?.currentUser?.uid||'guest'};
  try{
   const net=await NetInfo.fetch();
   if(net.isConnected && db){
    if(image){const blob=await (await fetch(image)).blob();const storage=getStorage();const rr=ref(storage,`posts/${Date.now()}`);await uploadBytes(rr,blob);data.imageUrl=await getDownloadURL(rr)}
    await addDoc(collection(db,'posts'),data);
    Alert.alert('Posted','Your NeedA post is live.');setTitle('');setPrice('');setImage(null);router.replace('/(tabs)');
   }else{
    const old=JSON.parse(await AsyncStorage.getItem('needa.queue')||'[]');old.push({...data,localImage:image});await AsyncStorage.setItem('needa.queue',JSON.stringify(old));Alert.alert('Saved offline','Your post is saved on this phone and will need to sync when you are online.');router.replace('/(tabs)');
   }
  }catch(e:any){Alert.alert('Could not post',e?.message||'Please try again.')}finally{setBusy(false)}
 };
 return <ScrollView style={s.page} contentContainerStyle={s.content}><Text style={s.title}>Add Post</Text><TextInput value={title} onChangeText={setTitle} placeholder="What are you offering or looking for?" style={s.input}/><TextInput value={price} onChangeText={setPrice} placeholder="Price (optional)" keyboardType="decimal-pad" style={s.input}/><View style={s.row}>{['Goods','Service','Trading','Need'].map(x=><TouchableOpacity key={x} onPress={()=>setType(x)} style={[s.type,{backgroundColor:type===x?purple:'#EEEBFB'}]}><Text style={{color:type===x?'#fff':purple,fontWeight:'800'}}>{x}</Text></TouchableOpacity>)}</View>{image&&<Image source={{uri:image}} style={s.preview}/>}<View style={s.row}><TouchableOpacity style={s.photo} onPress={choose}><Text style={s.photoText}>📷 Choose from phone</Text></TouchableOpacity><TouchableOpacity style={s.photo} onPress={camera}><Text style={s.photoText}>Camera</Text></TouchableOpacity></View><TouchableOpacity style={s.loc} onPress={async()=>{const p=await Location.requestForegroundPermissionsAsync();if(p.status==='granted'){const l=await Location.getCurrentPositionAsync({});Alert.alert('Location set',`${l.coords.latitude.toFixed(5)}, ${l.coords.longitude.toFixed(5)}`)}}}><Text style={s.photoText}>📍 Set location</Text></TouchableOpacity><TouchableOpacity disabled={busy} onPress={submit} style={s.submit}><Text style={s.submitText}>{busy?'Posting…':'Publish on NeedA'}</Text></TouchableOpacity></ScrollView>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#F6F6FB'},content:{padding:18,paddingBottom:110},title:{fontSize:29,fontWeight:'900',color:'#1D1B2E',marginTop:12,marginBottom:18},input:{height:54,backgroundColor:'#fff',borderWidth:1,borderColor:'#E9E8F2',borderRadius:16,paddingHorizontal:15,fontSize:15,marginBottom:12},row:{flexDirection:'row',gap:8,flexWrap:'wrap'},type:{paddingHorizontal:15,paddingVertical:11,borderRadius:14},preview:{width:'100%',height:240,borderRadius:18,marginVertical:12,resizeMode:'cover'},photo:{flex:1,minWidth:145,backgroundColor:'#fff',borderWidth:1,borderColor:'#E9E8F2',borderRadius:16,padding:16,alignItems:'center',marginTop:12},photoText:{color:purple,fontWeight:'800'},loc:{backgroundColor:'#EEEBFB',borderRadius:16,padding:16,alignItems:'center',marginTop:12},submit:{backgroundColor:purple,borderRadius:17,padding:17,alignItems:'center',marginTop:22},submitText:{color:'#fff',fontSize:16,fontWeight:'900'}});
