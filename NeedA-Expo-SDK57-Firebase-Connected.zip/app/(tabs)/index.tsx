import React,{useCallback,useEffect,useState} from 'react';
import {ScrollView,View,Text,StyleSheet,Image,TouchableOpacity,RefreshControl,Dimensions} from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import {useRouter} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {fetchPosts,fetchShops} from '../../src/lib/firebase';
import {cacheJson,filterActive,readJson} from '../../src/lib/offline';
import {OfflineBanner} from '../../src/components/OfflineBanner';

const purple='#4F3CC9', cream='#F6F6FB', ink='#1D1B2E', muted='#6B6878';
const ads=[
 require('../../assets/needa-splash/ad-1.jpg'),require('../../assets/needa-splash/ad-2.jpg'),
 require('../../assets/needa-splash/ad-3.jpg'),require('../../assets/needa-splash/ad-4.jpg'),
 require('../../assets/needa-splash/ad-5.jpg'),require('../../assets/needa-splash/ad-6.jpg'),
 require('../../assets/needa-splash/ad-7.jpg'),require('../../assets/needa-splash/ad-8.jpg'),
 require('../../assets/needa-splash/ad-9.jpg'),require('../../assets/needa-splash/ad-10.jpg')
];
const cats=[['Home Services','hammer-outline'],['Electronics','hardware-chip-outline'],['Phones','phone-portrait-outline'],['Transport','car-outline'],['Beauty','sparkles-outline'],['Food','restaurant-outline'],['Shopping','cart-outline'],['Jobs','briefcase-outline']];

export default function Home(){
 const router=useRouter(); const [posts,setPosts]=useState<any[]>([]); const [shops,setShops]=useState<any[]>([]);
 const [offline,setOffline]=useState(false); const [refreshing,setRefreshing]=useState(false); const [ad,setAd]=useState(0);
 const load=useCallback(async()=>{
  setRefreshing(true);
  const state=await NetInfo.fetch(); setOffline(!state.isConnected);
  if(!state.isConnected){setPosts(await readJson('needa.posts',[]));setShops(await readJson('needa.shops',[]));setRefreshing(false);return;}
  try{const [p,s]=await Promise.all([fetchPosts(),fetchShops()]);const ap=filterActive(p as any[]);setPosts(ap);setShops(s);await cacheJson('needa.posts',ap);await cacheJson('needa.shops',s)}catch{setOffline(true);setPosts(await readJson('needa.posts',[]));setShops(await readJson('needa.shops',[]))}
  setRefreshing(false);
 },[]);
 useEffect(()=>{load();const sub=NetInfo.addEventListener(x=>setOffline(!x.isConnected));const t=setInterval(()=>setAd(x=>(x+1)%ads.length),5000);return()=>{sub();clearInterval(t)}},[load]);
 return <View style={{flex:1,backgroundColor:cream}}>
  <ScrollView contentContainerStyle={s.container} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load}/>}>
   <View style={s.top}><View style={s.logoRow}><Image source={require('../../assets/brand/needa-logo.png')} style={s.logo}/><Text style={s.brand}>NeedA</Text></View><TouchableOpacity onPress={()=>router.push('/(tabs)/profile')}><Ionicons name="person-circle-outline" size={34} color={purple}/></TouchableOpacity></View>
   <View style={s.search}><Ionicons name="search-outline" size={22} color={muted}/><Text style={{color:muted,fontSize:15}}>Search products, services, shops...</Text></View>
   <View style={s.hero}><Image source={ads[ad]} style={s.heroImg}/><View style={s.heroShade}/><View style={s.heroText}><Text style={s.heroTitle}>Need help? Find it nearby.</Text><Text style={s.heroSub}>Shops • Services • Goods • People</Text></View></View>
   <View style={s.dots}>{ads.slice(0,6).map((_,i)=><View key={i} style={[s.dot,{opacity:i===ad%6?1:.3}]}/>)}</View>
   <Section title="Categories" action="See all"/>
   <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.catRow}>{cats.map(([label,icon])=><TouchableOpacity key={label} style={s.cat} onPress={()=>router.push({pathname:'/(tabs)/shops',params:{category:label}})}><View style={s.catIcon}><Ionicons name={icon as any} size={25} color={purple}/></View><Text style={s.catText}>{label}</Text></TouchableOpacity>)}</ScrollView>
   <Section title="Local Shops" action="See all"/>
   <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.shopRow}>{shops.slice(0,10).map((x:any)=><TouchableOpacity key={x.id} style={s.shop} onPress={()=>router.push({pathname:'/shop/[id]',params:{id:x.id}})}><View style={s.shopImage}>{x.logoUrl||x.photoUrl?<Image source={{uri:x.logoUrl||x.photoUrl}} style={s.shopImg}/>:<Ionicons name="storefront-outline" size={34} color={purple}/>}</View><Text numberOfLines={1} style={s.shopName}>{x.shopName||x.businessName||'Local Shop'}</Text><Text numberOfLines={1} style={s.shopLoc}>{x.locationName||'Zambia'}</Text></TouchableOpacity>)}</ScrollView>
   <Section title="Updates" action={`${posts.length}`}/>
   <View style={s.grid}>{posts.slice(0,20).map((p:any)=><TouchableOpacity key={p.id} style={s.card} onPress={()=>router.push({pathname:'/post/[id]',params:{id:p.id}})}><View style={s.cardImage}>{p.imageUrl?<Image source={{uri:p.imageUrl}} style={s.cardImg}/>:<Image source={ads[(Number(p.id?.length)||0)%ads.length]} style={s.cardImg}/>}<View style={s.badge}><Text style={s.badgeText}>{p.type||'LOCAL'}</Text></View></View><Text numberOfLines={2} style={s.cardTitle}>{p.title||p.description||'NeedA update'}</Text><Text style={s.price}>{p.price?`ZMW ${p.price}`:'View details'}</Text></TouchableOpacity>)}</View>
  </ScrollView>
  <OfflineBanner offline={offline}/>
 </View>
}
function Section({title,action}:{title:string,action:string}){return <View style={s.sectionHead}><Text style={s.sectionTitle}>{title}</Text><Text style={s.action}>{action}</Text></View>}
const W=Dimensions.get('window').width;
const s=StyleSheet.create({
 container:{padding:16,paddingBottom:100},top:{height:48,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},logoRow:{flexDirection:'row',alignItems:'center',gap:8},logo:{width:38,height:38,borderRadius:19},brand:{fontSize:23,fontWeight:'900',color:ink},search:{height:50,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#E9E8F2',marginTop:12,flexDirection:'row',alignItems:'center',gap:10,paddingHorizontal:15},hero:{marginTop:16,height:Math.min(260,W*.58),borderRadius:22,overflow:'hidden',backgroundColor:purple},heroImg:{width:'100%',height:'100%',resizeMode:'cover'},heroShade:{position:'absolute',top:0,right:0,bottom:0,left:0,backgroundColor:'rgba(46,33,120,.38)'},heroText:{position:'absolute',left:18,bottom:18},heroTitle:{color:'#fff',fontSize:23,fontWeight:'900'},heroSub:{color:'#fff',fontSize:13,marginTop:5,fontWeight:'600'},dots:{flexDirection:'row',justifyContent:'center',gap:5,marginTop:8},dot:{width:7,height:7,borderRadius:4,backgroundColor:purple},sectionHead:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginTop:22,marginBottom:11},sectionTitle:{fontSize:20,fontWeight:'900',color:ink},action:{color:purple,fontWeight:'700'},catRow:{gap:12,paddingBottom:2},cat:{width:82,alignItems:'center'},catIcon:{width:58,height:58,borderRadius:18,backgroundColor:'#EEEBFB',alignItems:'center',justifyContent:'center'},catText:{fontSize:11,fontWeight:'700',color:ink,textAlign:'center',marginTop:6},shopRow:{gap:12},shop:{width:128,backgroundColor:'#fff',borderRadius:17,padding:9,borderWidth:1,borderColor:'#E9E8F2'},shopImage:{height:94,borderRadius:13,backgroundColor:'#EEEBFB',alignItems:'center',justifyContent:'center',overflow:'hidden'},shopImg:{width:'100%',height:'100%',resizeMode:'cover'},shopName:{fontSize:13,fontWeight:'800',marginTop:7,color:ink},shopLoc:{fontSize:11,color:muted,marginTop:3},grid:{flexDirection:'row',flexWrap:'wrap',gap:12},card:{width:(W-44)/2,backgroundColor:'#fff',borderRadius:17,padding:9,borderWidth:1,borderColor:'#E9E8F2'},cardImage:{height:(W-44)/2,backgroundColor:'#EEEBFB',borderRadius:13,overflow:'hidden'},cardImg:{width:'100%',height:'100%',resizeMode:'cover'},badge:{position:'absolute',top:8,left:8,backgroundColor:'rgba(29,27,46,.8)',borderRadius:10,paddingHorizontal:8,paddingVertical:4},badgeText:{color:'#fff',fontSize:9,fontWeight:'800'},cardTitle:{fontSize:13,fontWeight:'800',color:ink,marginTop:8},price:{fontSize:12,fontWeight:'900',color:'#D6304A',marginTop:5}
});
