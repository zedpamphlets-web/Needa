import React from 'react';
import {Tabs} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {Platform} from 'react-native';

const purple='#4F3CC9';
export default function TabLayout(){
 return <Tabs screenOptions={{
   headerShown:false,
   tabBarActiveTintColor:purple,
   tabBarInactiveTintColor:'#6B6878',
   tabBarStyle:{height:72,paddingTop:7,paddingBottom:8,borderTopWidth:1,borderTopColor:'#E9E8F2',backgroundColor:'#fff'},
   tabBarLabelStyle:{fontSize:12,fontWeight:'700'},
   tabBarIconStyle:{marginBottom:0},
 }}>
  <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:({color})=><Ionicons name="home-outline" size={30} color={color}/>}}/>
  <Tabs.Screen name="shops" options={{title:'Shops',tabBarIcon:({color})=><Ionicons name="storefront-outline" size={30} color={color}/>}}/>
  <Tabs.Screen name="trading" options={{title:'Trading',tabBarIcon:({color})=><Ionicons name="trending-up-outline" size={30} color={color}/>}}/>
  <Tabs.Screen name="add" options={{title:'Add Post',tabBarIcon:({color})=><Ionicons name="add-circle-outline" size={32} color={color}/>}}/>
  <Tabs.Screen name="profile" options={{title:'Profile',tabBarIcon:({color})=><Ionicons name="person-outline" size={30} color={color}/>}}/>
 </Tabs>
}
