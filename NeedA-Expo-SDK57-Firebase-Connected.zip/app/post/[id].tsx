import React,{useEffect,useState} from 'react';
import {View,Text,StyleSheet,Image,ScrollView} from 'react-native';
import {doc,getDoc} from 'firebase/firestore';
import {db} from '../../src/lib/firebase';
import {useLocalSearchParams} from 'expo-router';
import {isExpired} from '../../src/lib/offline';
export default function Post(){
 const {id}=useLocalSearchParams<{id:string}>();const [x,setX]=useState<any>(null);
 useEffect(()=>{(async()=>{try{if(!db)return; const d=await getDoc(doc(db,'posts',String(id)));if(d.exists())setX({id:d.id,...d.data()})}catch{}})()},[id]);
 if(!x)return <View style={s.center}><Text>Loading…</Text></View>;
 if(isExpired(x.expiresAt))return <View style={s.center}><Text>This update has expired.</Text></View>;
 return <ScrollView style={s.page} contentContainerStyle={s.content}>{x.imageUrl?<Image source={{uri:x.imageUrl}} style={s.image}/>:null}<Text style={s.type}>{x.type||'UPDATE'}</Text><Text style={s.title}>{x.title||x.description||'NeedA post'}</Text>{x.price?<Text style={s.price}>ZMW {x.price}</Text>:null}<Text style={s.body}>{x.description||'No additional details.'}</Text></ScrollView>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#F6F6FB'},content:{padding:18,paddingBottom:100},center:{flex:1,alignItems:'center',justifyContent:'center'},image:{width:'100%',height:320,borderRadius:22,resizeMode:'cover'},type:{color:'#4F3CC9',fontWeight:'900',marginTop:16},title:{fontSize:28,fontWeight:'900',color:'#1D1B2E',marginTop:7},price:{fontSize:18,fontWeight:'900',color:'#D6304A',marginTop:8},body:{fontSize:15,lineHeight:23,color:'#6B6878',marginTop:16}});
