import React,{useEffect,useState} from 'react';
import {View,Image,StyleSheet,Text} from 'react-native';
import {Stack} from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import {StatusBar} from 'expo-status-bar';
import NetInfo from '@react-native-community/netinfo';
import {syncQueuedPosts} from '../src/lib/firebase';

SplashScreen.preventAutoHideAsync().catch(()=>{});

export default function RootLayout(){
  const [opening,setOpening]=useState(true);
  useEffect(()=>{
    NetInfo.fetch().then(n=>{if(n.isConnected) syncQueuedPosts().catch(()=>{})});
    const sub=NetInfo.addEventListener(n=>{if(n.isConnected) syncQueuedPosts().catch(()=>{})});
    const t=setTimeout(async()=>{await SplashScreen.hideAsync();},700);
    const end=setTimeout(()=>setOpening(false),15700);
    return ()=>{clearTimeout(t);clearTimeout(end);sub();};
  },[]);
  return <>
    <Stack screenOptions={{headerShown:false}} />
    <StatusBar style="dark"/>
    {opening && <View style={s.overlay}>
      <Image source={require('../assets/needa-splash/needa-splash-collage.png')} style={s.bg}/>
      <View style={s.shade}/>
      <Image source={require('../assets/brand/needa-logo.png')} style={s.logo}/>
      <Text style={s.title}>NEEDA</Text>
      <Text style={s.sub}>You need it. Someone can help.</Text>
      <View style={s.line}><View style={s.progress}/></View>
    </View>}
  </>
}
const s=StyleSheet.create({
 overlay:{position:'absolute',top:0,right:0,bottom:0,left:0,backgroundColor:'#4F3CC9',zIndex:999,alignItems:'center',justifyContent:'center'},
 bg:{position:'absolute',top:0,right:0,bottom:0,left:0,width:'100%',height:'100%',resizeMode:'cover'},
 shade:{position:'absolute',top:0,right:0,bottom:0,left:0,backgroundColor:'rgba(46,33,120,.70)'},
 logo:{width:112,height:112,resizeMode:'contain',marginBottom:14},
 title:{color:'#fff',fontSize:38,fontWeight:'900',letterSpacing:2},
 sub:{color:'#fff',fontSize:15,marginTop:8,opacity:.95},
 line:{position:'absolute',bottom:70,left:46,right:46,height:5,borderRadius:4,backgroundColor:'rgba(255,255,255,.25)',overflow:'hidden'},
 progress:{height:'100%',width:'62%',backgroundColor:'#fff',borderRadius:4}
});
