import React,{useEffect,useState} from 'react';
import {View,Text,StyleSheet,Image,ScrollView,TouchableOpacity,Linking} from 'react-native';
import {doc,getDoc} from 'firebase/firestore';
import {db} from '../../src/lib/firebase';
import {useLocalSearchParams} from 'expo-router';
export default function Shop(){
 const {id}=useLocalSearchParams<{id:string}>();const [x,setX]=useState<any>(null);
 useEffect(()=>{(async()=>{try{if(!db)return; const d=await getDoc(doc(db,'users',String(id)));if(d.exists())setX({id:d.id,...d.data()})}catch{}})()},[id]);
 if(!x)return <View style={s.center}><Text>Loading shop…</Text></View>;
 return <ScrollView style={s.page} contentContainerStyle={s.content}>{x.logoUrl||x.photoUrl?<Image source={{uri:x.logoUrl||x.photoUrl}} style={s.cover}/>:null}<Text style={s.title}>{x.shopName||x.businessName||'Local Shop'}</Text><Text style={s.meta}>{x.locationName||'Zambia'} • {x.openingHours||'08:00-19:00'}</Text><View style={s.actions}><TouchableOpacity style={s.button} onPress={()=>x.phone&&Linking.openURL(`tel:${x.phone}`)}><Text style={s.bt}>Call</Text></TouchableOpacity><TouchableOpacity style={s.button} onPress={()=>x.whatsapp&&Linking.openURL(`https://wa.me/${x.whatsapp}`)}><Text style={s.bt}>WhatsApp</Text></TouchableOpacity></View><Text style={s.head}>About this shop</Text><Text style={s.body}>{x.about||'A local business or service provider on NeedA.'}</Text></ScrollView>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#F6F6FB'},content:{padding:18,paddingBottom:100},center:{flex:1,alignItems:'center',justifyContent:'center'},cover:{width:'100%',height:260,borderRadius:22,resizeMode:'cover'},title:{fontSize:29,fontWeight:'900',color:'#1D1B2E',marginTop:16},meta:{color:'#6B6878',marginTop:6},actions:{flexDirection:'row',gap:10,marginTop:18},button:{flex:1,backgroundColor:'#4F3CC9',padding:16,borderRadius:16,alignItems:'center'},bt:{color:'#fff',fontWeight:'900'},head:{fontSize:20,fontWeight:'900',marginTop:28},body:{fontSize:15,lineHeight:23,color:'#6B6878',marginTop:8}});
