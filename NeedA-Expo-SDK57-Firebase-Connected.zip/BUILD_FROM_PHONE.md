# NeedA — build from an Android phone

Open the project folder in Termux.

```bash
npm install
npx expo install --fix
npx expo-doctor
```

If Expo Doctor is clean, log in:

```bash
eas login
eas whoami
```

Configure EAS if needed:

```bash
eas build:configure
```

Build an installable Android APK:

```bash
eas build --platform android --profile preview
```

For Google Play, build the production Android App Bundle:

```bash
eas build --platform android --profile production
```

Never paste an Expo token, password, Firebase private key, or signing credential into chat.
