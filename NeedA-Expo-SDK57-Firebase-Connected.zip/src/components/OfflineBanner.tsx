import React from 'react';
import {StyleSheet,Text,View} from 'react-native';

export function OfflineBanner({offline}:{offline:boolean}) {
  if(!offline) return null;
  return <View style={s.box}><Text style={s.text}>Offline mode — showing saved content.</Text></View>
}
const s=StyleSheet.create({box:{position:'absolute',left:18,right:18,bottom:82,zIndex:50,backgroundColor:'#1D1B2E',borderRadius:16,padding:10},text:{color:'#fff',textAlign:'center',fontSize:13,fontWeight:'600'}});
