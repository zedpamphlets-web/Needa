import AsyncStorage from '@react-native-async-storage/async-storage';
import { getApps, getApp, initializeApp, type FirebaseApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence, type Auth } from 'firebase/auth';
import { getFirestore, collection, getDocs, limit, orderBy, query, addDoc, type Firestore } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
};

const configured = Object.values(firebaseConfig).every(Boolean);
let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

if (configured) {
  app = getApps().length ? getApp() : initializeApp(firebaseConfig as any);
  try {
    auth = initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
  } catch {
    auth = getAuth(app);
  }
  db = getFirestore(app);
}

export { app, auth, db, configured };

export async function fetchPosts(limitCount = 100) {
  if (!db) throw new Error('Firebase is not configured yet.');
  const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(limitCount));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function fetchShops(limitCount = 50) {
  if (!db) throw new Error('Firebase is not configured yet.');
  const q = query(collection(db, 'users'), limit(limitCount));
  const snap = await getDocs(q);
  return snap.docs
    .map(d => ({ id: d.id, ...d.data() }))
    .filter((x: any) => x.accountType === 'business');
}

export async function syncQueuedPosts() {
  if (!app || !db) return;
  const raw = await AsyncStorage.getItem('needa.queue');
  if (!raw) return;
  const queue = JSON.parse(raw);
  if (!Array.isArray(queue) || !queue.length) return;
  const remaining: any[] = [];
  for (const item of queue) {
    try {
      const data = { ...item };
      delete data.localImage;
      if (item.localImage) {
        const blob = await (await fetch(item.localImage)).blob();
        const rr = ref(getStorage(app), `posts/${Date.now()}-${Math.random().toString(36).slice(2)}`);
        await uploadBytes(rr, blob);
        data.imageUrl = await getDownloadURL(rr);
      }
      await addDoc(collection(db, 'posts'), data);
    } catch {
      remaining.push(item);
    }
  }
  if (remaining.length) await AsyncStorage.setItem('needa.queue', JSON.stringify(remaining));
  else await AsyncStorage.removeItem('needa.queue');
}
