import AsyncStorage from '@react-native-async-storage/async-storage';

export async function cacheJson(key:string, value:unknown) {
  try { await AsyncStorage.setItem(key, JSON.stringify(value)); } catch {}
}
export async function readJson<T>(key:string, fallback:T):Promise<T> {
  try {
    const raw=await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch { return fallback; }
}
export function isExpired(value:any) {
  if (value == null || value === '') return false;
  let t = typeof value === 'number' ? value : Date.parse(String(value));
  if (!Number.isFinite(t)) return false;
  if (t < 10_000_000_000) t *= 1000;
  return t <= Date.now();
}
export function filterActive<T extends Record<string,any>>(items:T[]) {
  const fields=['expiresAt','expiryDate','expiresOn','expires','expirationDate','validUntil','endDate'];
  return items.filter(item => !fields.some(f => isExpired(item[f])));
}
